const dev = "http://localhost:5000"
export const baseUrl = window.location.hostname.split(":")[0] === "localhost" ? dev : "";